/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>


#include<stdio.h>
int main()
  {
//   variable initialization
    int a,b,c;
    printf("enter three numbers \n");
    scanf("%d%d%d",&a,&b,&c);  //input three no.
    
    if(a>b && a<c) //a is smaller than c and greater then b
    {
        printf("%d is middle no.",a);
        }

      
      else if (b>a && b<c) //b is smaller than c and greater then a
      {
        printf("%d is middle no.",b);
        }
       

      else{
    printf(" %d is middle no.",c);
      }
      return 0;

}


