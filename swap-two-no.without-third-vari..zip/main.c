/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a,b;
  printf("Enter two no. \n"); //10,20
  scanf("%d%d",&a,&b);
  printf("Before Swapping a is %d & b is %d \n",a,b); // a=10,b=20
  a=a+b;// a= 10+20=30
  b=a-b;// b= 30-20=10
  a=a-b; // a =30-10=20
  printf("After Swapping a is %d & b is %d",a,b);

    return 0;
}

