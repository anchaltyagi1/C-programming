/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/



#include<stdio.h>
int main()
 {

    int a,b,c;
    printf("enter three numbers \n");
    scanf("%d%d%d",&a,&b,&c);
    
    if(a<b && a<c)// a is smaller then b and c
    {
        printf("%d is smaller",a);//print a is smaller
        }

      
      else if (b<a && b<c)// b is smaller then a and c
      {
        printf("%d is smaller",b); //print b is smaller
        }
       

      else{
    printf(" %d is smaller",c);//print c is smaller
      }
      return 0;

}



