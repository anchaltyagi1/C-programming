/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    // Calculator
    int a,b;
    printf("Enter first number:");//10
    scanf("%d",&a);
    printf("Enter second number:");//2
    scanf("%d",&b);
    int s;
    s=a+b;//12
    printf("sum of two numbers is %d", s);
    int sub;
    sub=a-b;//8
     printf("\nDifference of two numbers is %d ", sub);
     int mul;
    mul=a*b;//20
     printf("\nmultiply of two numbers is %d ", mul);
      int divi;
    divi=a/b;//5
     printf("\nQuotient  is %d ", divi);
     int rem;
     rem=a%b;//0
     printf(" \nRemainder is %d",rem);
    
    

    return 0;
}

