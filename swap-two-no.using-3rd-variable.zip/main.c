/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a,b,c;
    
    printf("Enter two no. \n"); //2,3
    scanf("%d%d",&a,&b);
     printf("Before swapping a  & b is %d  %d \n",a,b);// a=2,b=3
   
    c=a+b; // c=5
    a=c-a; //a=5-2=3
    b=c-b; //b=5-3=2
    printf("after swapping a  & b is %d %d",a,b); //a=3,b=2
    return 0;
}
